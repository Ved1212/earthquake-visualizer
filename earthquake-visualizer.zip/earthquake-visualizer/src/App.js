import React from "react";
import EarthquakeMap from "./components/EarthquakeMap";

function App() {
  return (
    <div>
      <h2 style={{ textAlign: "center" }}>🌍 Earthquake Visualizer</h2>
      <EarthquakeMap />
    </div>
  );
}

export default App;
