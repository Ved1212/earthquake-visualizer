import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Circle, Popup } from "react-leaflet";
import axios from "axios";

const EarthquakeMap = () => {
  const [quakes, setQuakes] = useState([]);

  useEffect(() => {
    axios
      .get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson")
      .then((res) => setQuakes(res.data.features))
      .catch((err) => console.error(err));
  }, []);

  return (
    <MapContainer center={[20, 0]} zoom={2} style={{ height: "100vh", width: "100%" }}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {quakes.map((quake) => {
        const [lon, lat, depth] = quake.geometry.coordinates;
        const mag = quake.properties.mag;

        return (
          <Circle
            key={quake.id}
            center={[lat, lon]}
            radius={mag * 10000}
            pathOptions={{
              color: mag >= 5 ? "red" : "orange",
              fillOpacity: 0.5,
            }}
          >
            <Popup>
              <strong>{quake.properties.place}</strong>
              <br />
              Magnitude: {mag}
              <br />
              Depth: {depth} km
              <br />
              Time: {new Date(quake.properties.time).toLocaleString()}
            </Popup>
          </Circle>
        );
      })}
    </MapContainer>
  );
};

export default EarthquakeMap;
